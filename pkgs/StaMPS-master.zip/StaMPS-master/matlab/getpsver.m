function [psver]=getpsver(new_psver)
% GETPSVER gets psver
%
%   Andy Hooper, June 2006


load psver

