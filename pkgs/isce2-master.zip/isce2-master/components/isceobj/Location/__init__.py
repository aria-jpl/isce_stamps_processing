#!/usr/bin/env python3
def createPeg():
    from Peg import Peg
    return Peg()
