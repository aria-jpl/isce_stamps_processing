void cpxPhaseFilter(Image<std::complex<float> > *image, Image<std::complex<float> > *result, Filter *filter);
void medianPhaseFilter(Image<std::complex<float> > *image, Image<std::complex<float> > *result, int filterWidth, int filterHeight);
