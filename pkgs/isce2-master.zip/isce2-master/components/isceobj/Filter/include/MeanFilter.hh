#include "Filter.hh"

class MeanFilter: public Filter
{
 public:
   MeanFilter(int width, int height);
};
