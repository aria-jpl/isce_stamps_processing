def createFrame(name=None):
    from .Frame import Frame
    return Frame(name=name)