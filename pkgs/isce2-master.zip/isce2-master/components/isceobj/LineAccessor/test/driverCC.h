#ifndef driverCC_h
#define driverCC_h

#include "driverCCFortTrans.h"
#include <stdint.h>

extern "C"
{
        void testImageSetGet_f(uint64_t *, uint64_t *, int *);

}

#endif //driverCC_h
